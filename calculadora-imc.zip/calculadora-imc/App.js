import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';

export default function App() {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [imc, setImc] = useState(null);
  const [classificacao, setClassificacao] = useState('');
  const [corClassificacao, setCorClassificacao] = useState('');
  const [erro, setErro] = useState('');

  const obterClassificacao = (valorImc) => {
    // Cores modernas baseadas na tabela
    if (valorImc < 18.5) return { texto: 'Abaixo do Peso', cor: '#F59E0B' }; // Laranja/Amarelo
    if (valorImc >= 18.5 && valorImc <= 24.9) return { texto: 'Peso Normal (Eutrofia)', cor: '#10B981' }; // Verde
    if (valorImc >= 25.0 && valorImc <= 29.9) return { texto: 'Sobrepeso', cor: '#D97706' }; // Amarelo Escuro
    if (valorImc >= 30.0 && valorImc <= 34.9) return { texto: 'Obesidade Grau I', cor: '#F97316' }; // Laranja
    if (valorImc >= 35.0 && valorImc <= 39.9) return { texto: 'Obesidade Grau II (Severa)', cor: '#EF4444' }; // Vermelho
    return { texto: 'Obesidade Grau III (Mórbida)', cor: '#991B1B' }; // Vermelho Escuro
  };

  const calcularIMC = () => {
    setErro('');
    
    const p = parseFloat(peso.replace(',', '.'));
    const a = parseFloat(altura.replace(',', '.'));

    if (!p || !a || a <= 0) {
      setErro('⚠️ Por favor, preencha os campos corretamente.'); // Alerta visual
      setImc(null);
      return;
    }

    const calcImc = p / (a * a); // Cálculo do IMC
    setImc(calcImc.toFixed(2)); // Arredondado para 2 casas

    const info = obterClassificacao(calcImc);
    setClassificacao(info.texto);
    setCorClassificacao(info.cor);
  };

  const limpar = () => {
    setPeso('');
    setAltura('');
    setImc(null);
    setClassificacao('');
    setCorClassificacao('');
    setErro('');
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer} keyboardShouldPersistTaps="handled">
        
        <View style={styles.header}>
          <Text style={styles.titulo}>Calculadora IMC</Text>
          <Text style={styles.subtitulo}>Projeto Lab. Dev Web</Text>
        </View>

        <View style={styles.card}>
          {erro ? <Text style={styles.erro}>{erro}</Text> : null}

          <Text style={styles.label}>Peso (kg)</Text>
          <TextInput
            style={styles.input}
            placeholder="Ex: 75"
            placeholderTextColor="#A0AEC0"
            keyboardType="numeric"
            value={peso}
            onChangeText={setPeso}
          />

          <Text style={styles.label}>Altura (m)</Text>
          <TextInput
            style={styles.input}
            placeholder="Ex: 1.75"
            placeholderTextColor="#A0AEC0"
            keyboardType="numeric"
            value={altura}
            onChangeText={setAltura}
          />

          {/* Botões Customizados */}
          <TouchableOpacity style={styles.botaoCalcular} onPress={calcularIMC} activeOpacity={0.8}>
            <Text style={styles.textoBotaoCalcular}>Calcular Meu IMC</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.botaoLimpar} onPress={limpar} activeOpacity={0.6}>
            <Text style={styles.textoBotaoLimpar}>Limpar Dados</Text>
          </TouchableOpacity>
        </View>

        {/* Card de Resultado */}
        {imc && (
          <View style={styles.resultadoCard}>
            <Text style={styles.resultadoLabel}>Seu Índice de Massa Corporal é:</Text>
            <Text style={styles.resultadoImc}>{imc}</Text>
            
            {/* Badge (Pílula) com a cor da classificação */}
            <View style={[styles.badge, { backgroundColor: corClassificacao + '20' }]}>
              <Text style={[styles.classificacaoTexto, { color: corClassificacao }]}>
                {classificacao}
              </Text>
            </View>
          </View>
        )}

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F4F6F9', // Fundo cinza bem claro e moderno
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  titulo: {
    fontSize: 32,
    fontWeight: '800',
    color: '#1A202C',
    letterSpacing: 0.5,
  },
  subtitulo: {
    fontSize: 16,
    color: '#718096',
    marginTop: 5,
    fontWeight: '500',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 5, // Sombra para Android
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4A5568',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#EDF2F7',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
    fontSize: 16,
    color: '#2D3748',
  },
  botaoCalcular: {
    backgroundColor: '#3B82F6', // Azul moderno
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#3B82F6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  textoBotaoCalcular: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
  botaoLimpar: {
    backgroundColor: '#F1F5F9',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  textoBotaoLimpar: {
    color: '#64748B',
    fontSize: 16,
    fontWeight: '600',
  },
  erro: {
    color: '#E53E3E',
    backgroundColor: '#FFF5F5',
    padding: 12,
    borderRadius: 8,
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: '600',
    overflow: 'hidden',
  },
  resultadoCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 5,
  },
  resultadoLabel: {
    fontSize: 16,
    color: '#718096',
    fontWeight: '500',
    marginBottom: 8,
  },
  resultadoImc: {
    fontSize: 48,
    fontWeight: '900',
    color: '#1A202C',
    marginBottom: 16,
  },
  badge: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20, // Formato de "pílula"
  },
  classificacaoTexto: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});